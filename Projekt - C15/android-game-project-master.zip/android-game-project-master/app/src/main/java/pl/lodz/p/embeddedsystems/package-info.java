/**
 * Pakiet zawierajcy zadanie na systemy wbudowane w semestrze 2020L dla grupy C15.
 *
 * @author Nowicki Artur 224388 (lider)
 * @author Maksajda Michał 224369
 * @author Guzek Paweł 224304
 * @version 1.0
 */
package pl.lodz.p.embeddedsystems;
